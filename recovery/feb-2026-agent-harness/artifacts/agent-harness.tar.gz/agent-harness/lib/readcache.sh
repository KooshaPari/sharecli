#!/usr/bin/env bash
# =============================================================================
# agent-harness/lib/readcache.sh — File Read Cache Subsystem
#
# Three layers of file read caching, each increasingly aggressive:
#
# Layer 1: PAGE CACHE WARMER (pure bash, zero deps)
#   Pre-touches files into the kernel page cache before a coalesced command
#   executes.  The command then runs entirely from RAM.  Integrated into
#   the harness coalesce strategy as a pre-exec hook.
#
# Layer 2: STAT CACHE (LD_PRELOAD, requires compilation)
#   Intercepts stat(), lstat(), readdir() at libc level.  Caches results
#   in shared memory for a configurable TTL (~100ms default).  All agent
#   subprocesses share the same stat cache, eliminating N× metadata storms.
#
# Layer 3: RAMDISK MIRROR (tmpfs, requires root for mount)
#   Syncs the project tree to a tmpfs mount.  Agents read from the ramdisk
#   via a bind mount or symlink.  Writes go through to the real filesystem
#   and trigger a background resync.  Maximum throughput for I/O-heavy tools.
#
# This file provides the bash-side plumbing for all three layers.
# The LD_PRELOAD shim source is in lib/statcache_shim.c.
# =============================================================================

# shellcheck source=lib/core.sh
SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null || realpath "${BASH_SOURCE[0]}" 2>/dev/null)")" && pwd)"
HARNESS_HOME="${HARNESS_HOME:-$(dirname "$SCRIPT_DIR")}"

# Defaults
RC_CACHE_DIR="${HARNESS_HOME}/var/readcache"
RC_LOG="${HARNESS_HOME}/var/log/readcache.log"
RC_WARM_MANIFEST="${RC_CACHE_DIR}/warm.manifest"  # files to pre-warm
RC_RAMDISK="${RC_CACHE_DIR}/ramdisk"

rc::log() {
    local level="$1"; shift
    mkdir -p "$(dirname "$RC_LOG")" 2>/dev/null
    printf '[%s] [readcache] [%s] %s\n' \
        "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$level" "$*" \
        >> "$RC_LOG" 2>/dev/null
}

# ============================================================================
# LAYER 1: PAGE CACHE WARMER
#
# Strategy: before a coalesced command runs, bulk-read the files it will
# touch into the kernel page cache.  This is simple and surprisingly
# effective — turns a 2.3s lint (cold) into a 0.8s lint (warm).
#
# Two modes:
#   1. Manifest-based: pre-computed list of files per command
#   2. Smart-scan: infer from command type (lint → all .py, typecheck → all .ts)
# ============================================================================

# Pre-warm files into page cache
# Usage: rc::warm <project_root> <command> <subcommand> [manifest_file]
rc::warm() {
    local project_root="$1"
    local cmd="$2"
    local subcmd="${3:-}"
    local manifest="${4:-}"
    local count=0

    mkdir -p "$RC_CACHE_DIR" 2>/dev/null

    if [[ -n "$manifest" && -f "$manifest" ]]; then
        # Mode 1: Explicit manifest
        rc::_warm_from_manifest "$manifest"
        return
    fi

    # Mode 2: Smart-scan based on command
    local -a patterns=()
    case "$cmd" in
        ruff|flake8|pylint|mypy|pyright|black|isort)
            patterns=("*.py")
            ;;
        eslint|prettier|biome)
            patterns=("*.ts" "*.tsx" "*.js" "*.jsx" "*.json")
            ;;
        tsc|vue-tsc)
            patterns=("*.ts" "*.tsx" "*.d.ts" "tsconfig*.json")
            ;;
        rustfmt|clippy)
            patterns=("*.rs" "Cargo.toml" "Cargo.lock")
            ;;
        cargo)
            case "$subcmd" in
                check|clippy|build)
                    patterns=("*.rs" "Cargo.toml" "Cargo.lock")
                    ;;
            esac
            ;;
        golangci-lint|gofmt|goimports)
            patterns=("*.go" "go.mod" "go.sum")
            ;;
        go)
            case "$subcmd" in
                vet|build)
                    patterns=("*.go" "go.mod" "go.sum")
                    ;;
            esac
            ;;
        *)
            # Unknown command, skip warming
            rc::log DEBUG "No warm pattern for: ${cmd} ${subcmd}"
            return 0
            ;;
    esac

    if [[ ${#patterns[@]} -eq 0 ]]; then
        return 0
    fi

    rc::log INFO "Warming page cache for: ${cmd} ${subcmd} (patterns: ${patterns[*]})"

    # Build find command with patterns
    local -a find_args=("$project_root")
    # Exclude common heavy dirs
    find_args+=(-type d \( -name node_modules -o -name .git -o -name .git-audit \
                -o -name __pycache__ -o -name .venv -o -name target \
                -o -name .next -o -name dist -o -name build \) -prune -o)

    # Add file patterns
    local first=true
    find_args+=(\()
    for pat in "${patterns[@]}"; do
        if [[ "$first" == true ]]; then
            first=false
        else
            find_args+=(-o)
        fi
        find_args+=(-name "$pat")
    done
    find_args+=(\) -type f -print)

    # Read files into page cache via cat > /dev/null
    # Use xargs for batching, limit parallelism to avoid thrashing
    count=$(find "${find_args[@]}" 2>/dev/null | \
        tee "${RC_CACHE_DIR}/last_warm_${cmd}.list" | \
        xargs -P4 -I{} cat {} 2>/dev/null | wc -c)

    local file_count
    file_count=$(wc -l < "${RC_CACHE_DIR}/last_warm_${cmd}.list" 2>/dev/null || echo 0)

    rc::log INFO "Warmed ${file_count} files (${count} bytes) for ${cmd} ${subcmd}"
}

rc::_warm_from_manifest() {
    local manifest="$1"
    xargs -P4 -a "$manifest" -I{} cat {} > /dev/null 2>&1
    rc::log INFO "Warmed $(wc -l < "$manifest") files from manifest"
}

# Generate a warm manifest from a command's actual file access
# (Uses strace to record what files the command opens)
# Usage: rc::record_manifest <project_root> <command> [args...]
rc::record_manifest() {
    local project_root="$1"; shift
    local cmd="$1"

    if ! command -v strace &>/dev/null; then
        rc::log WARN "strace not available, cannot record manifest"
        return 1
    fi

    mkdir -p "$RC_CACHE_DIR" 2>/dev/null

    local manifest="${RC_CACHE_DIR}/manifest_${cmd}.list"
    local trace_file="${RC_CACHE_DIR}/trace_${cmd}.raw"

    # Trace open/openat/stat calls
    strace -f -e trace=open,openat,stat,lstat,newfstatat \
        -o "$trace_file" \
        "$@" >/dev/null 2>&1

    # Parse trace output → unique file paths within project
    grep -oP '(?:open|openat|stat|lstat)\([^,]*"([^"]+)"' "$trace_file" 2>/dev/null | \
        grep -oP '"[^"]+"' | tr -d '"' | \
        grep "^${project_root}" | \
        grep -v -E '(node_modules|\.git|__pycache__|\.pyc$)' | \
        sort -u > "$manifest"

    local count
    count=$(wc -l < "$manifest")
    rc::log INFO "Recorded manifest for ${cmd}: ${count} files → ${manifest}"
    rm -f "$trace_file"

    echo "$manifest"
}

# ============================================================================
# LAYER 2: STAT CACHE (LD_PRELOAD coordination)
#
# The actual caching is done by the C shim (lib/statcache_shim.c).
# This section provides:
#   - Compilation helper
#   - Environment setup for injection
#   - Shared memory management
#   - Integration with the harness
# ============================================================================

RC_SHIM_SRC="${HARNESS_HOME}/lib/statcache_shim.c"
RC_SHIM_SO="${HARNESS_HOME}/lib/statcache_shim.so"

# Compile the LD_PRELOAD shim
rc::compile_shim() {
    if [[ ! -f "$RC_SHIM_SRC" ]]; then
        rc::log ERROR "Shim source not found: ${RC_SHIM_SRC}"
        return 1
    fi

    if ! command -v gcc &>/dev/null; then
        rc::log WARN "gcc not available, cannot compile stat cache shim"
        return 1
    fi

    gcc -shared -fPIC -O2 \
        -o "$RC_SHIM_SO" \
        "$RC_SHIM_SRC" \
        -ldl -lpthread \
        2>&1

    if [[ $? -eq 0 ]]; then
        rc::log INFO "Compiled stat cache shim: ${RC_SHIM_SO}"
        return 0
    else
        rc::log ERROR "Failed to compile stat cache shim"
        return 1
    fi
}

# Set up environment variables to inject the shim
# Usage: eval "$(rc::shim_env)"
rc::shim_env() {
    if [[ ! -f "$RC_SHIM_SO" ]]; then
        return 0  # No shim compiled, no-op
    fi

    cat <<ENV
export LD_PRELOAD="${RC_SHIM_SO}:\${LD_PRELOAD:-}"
export HARNESS_STATCACHE_TTL_MS="${HARNESS_STATCACHE_TTL_MS:-100}"
export HARNESS_STATCACHE_DIR="${RC_CACHE_DIR}/shm"
export HARNESS_STATCACHE_ENABLED=1
ENV
}

# Check if shim is available and working
rc::shim_available() {
    [[ -f "$RC_SHIM_SO" ]] && return 0
    return 1
}

# ============================================================================
# LAYER 3: RAMDISK MIRROR
#
# Full tmpfs-backed copy of the project.  Agents read from the ramdisk,
# writes sync back to the real filesystem.  Maximum throughput.
#
# Requires root for tmpfs mount, or uses a regular directory in /dev/shm
# as a fallback (still RAM-backed on Linux).
# ============================================================================

# Initialize ramdisk mirror for a project
# Usage: rc::ramdisk_init <project_root> [size_mb]
rc::ramdisk_init() {
    local project_root="$1"
    local size_mb="${2:-512}"
    local project_name
    project_name="$(basename "$project_root")"
    local mirror_dir="${RC_RAMDISK}/${project_name}"

    # Prefer /dev/shm (no root needed, already tmpfs on Linux)
    if [[ -d /dev/shm && -w /dev/shm ]]; then
        mirror_dir="/dev/shm/agent-harness/${project_name}"
        mkdir -p "$mirror_dir"
        rc::log INFO "Using /dev/shm for ramdisk mirror: ${mirror_dir}"
    elif [[ $EUID -eq 0 ]]; then
        mkdir -p "$mirror_dir"
        mount -t tmpfs -o size=${size_mb}m tmpfs "$mirror_dir"
        rc::log INFO "Mounted tmpfs ramdisk: ${mirror_dir} (${size_mb}MB)"
    else
        rc::log ERROR "Cannot create ramdisk: need root for tmpfs, or /dev/shm not available"
        return 1
    fi

    # Initial sync (exclude heavy dirs)
    rsync -a \
        --exclude='.git/' \
        --exclude='.git-audit/' \
        --exclude='node_modules/' \
        --exclude='__pycache__/' \
        --exclude='.venv/' \
        --exclude='target/' \
        --exclude='.next/' \
        --exclude='dist/' \
        --exclude='build/' \
        "$project_root/" "$mirror_dir/"

    local file_count
    file_count="$(find "$mirror_dir" -type f | wc -l)"
    local size
    size="$(du -sh "$mirror_dir" 2>/dev/null | cut -f1)"

    rc::log INFO "Ramdisk mirror initialized: ${file_count} files, ${size}"

    # Write mirror metadata
    cat > "${mirror_dir}/.harness-mirror" <<META
source=${project_root}
created=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
META

    echo "$mirror_dir"
}

# Start background sync daemon (real → ramdisk, on inotify events)
# Usage: rc::ramdisk_watch <project_root> <mirror_dir>
rc::ramdisk_watch() {
    local project_root="$1"
    local mirror_dir="$2"
    local pidfile="${mirror_dir}/.harness-mirror.pid"

    if [[ -f "$pidfile" ]] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
        rc::log INFO "Ramdisk watcher already running"
        return 0
    fi

    if ! command -v inotifywait &>/dev/null; then
        rc::log ERROR "inotifywait required for ramdisk sync"
        return 1
    fi

    (
        local exclude_regex='\.git/|\.git-audit/|node_modules/|__pycache__/'

        inotifywait -m -r \
            --exclude "$exclude_regex" \
            -e modify,create,delete,move \
            --format '%e %w%f' \
            "$project_root" 2>/dev/null |
        while IFS= read -r line; do
            local event="${line%% *}"
            local filepath="${line#* }"

            # Skip mirror-internal files
            [[ "$filepath" == *".harness-mirror"* ]] && continue

            # Compute relative path
            local relpath="${filepath#${project_root}/}"

            case "$event" in
                *DELETE*)
                    rm -f "${mirror_dir}/${relpath}" 2>/dev/null
                    ;;
                *MOVED_FROM*)
                    rm -f "${mirror_dir}/${relpath}" 2>/dev/null
                    ;;
                *CREATE*|*MODIFY*|*MOVED_TO*)
                    local target_dir
                    target_dir="$(dirname "${mirror_dir}/${relpath}")"
                    mkdir -p "$target_dir" 2>/dev/null
                    cp -a "$filepath" "${mirror_dir}/${relpath}" 2>/dev/null
                    ;;
            esac
        done
    ) &

    echo $! > "$pidfile"
    rc::log INFO "Ramdisk watcher started (pid $(cat "$pidfile"))"
}

# Stop ramdisk sync and optionally unmount
rc::ramdisk_stop() {
    local mirror_dir="$1"
    local pidfile="${mirror_dir}/.harness-mirror.pid"

    if [[ -f "$pidfile" ]]; then
        kill "$(cat "$pidfile")" 2>/dev/null
        rm -f "$pidfile"
        rc::log INFO "Ramdisk watcher stopped"
    fi
}

rc::ramdisk_destroy() {
    local mirror_dir="$1"
    rc::ramdisk_stop "$mirror_dir"

    if mountpoint -q "$mirror_dir" 2>/dev/null; then
        umount "$mirror_dir"
    fi
    rm -rf "$mirror_dir"
    rc::log INFO "Ramdisk destroyed: ${mirror_dir}"
}

# ============================================================================
# INTEGRATION: Hook into the harness coalesce strategy
# ============================================================================

# Called by the harness before executing a coalesced command.
# Performs the appropriate level of read caching.
#
# Usage: rc::pre_exec <project_root> <command> <subcommand> [readcache_level]
#
# readcache_level:
#   0 = disabled
#   1 = page cache warm (default)
#   2 = page cache warm + LD_PRELOAD stat cache
#   3 = ramdisk mirror (commands execute against ramdisk)
#
rc::pre_exec() {
    local project_root="$1"
    local cmd="$2"
    local subcmd="${3:-}"
    local level="${4:-1}"

    case "$level" in
        0) return 0 ;;
        1)
            rc::warm "$project_root" "$cmd" "$subcmd"
            ;;
        2)
            rc::warm "$project_root" "$cmd" "$subcmd"
            if rc::shim_available; then
                eval "$(rc::shim_env)"
            fi
            ;;
        3)
            # Find or create ramdisk mirror
            local project_name
            project_name="$(basename "$project_root")"
            local mirror_dir="/dev/shm/agent-harness/${project_name}"
            if [[ ! -d "$mirror_dir" ]]; then
                mirror_dir="$(rc::ramdisk_init "$project_root")"
            fi
            # Command will be executed with CWD pointed at mirror
            export HARNESS_EXEC_CWD="$mirror_dir"
            ;;
    esac
}

# Called by the harness after a coalesced command completes.
# For ramdisk mode, syncs any writes back to the real filesystem.
#
# Usage: rc::post_exec <project_root> <command> [readcache_level]
rc::post_exec() {
    local project_root="$1"
    local cmd="$2"
    local level="${3:-1}"

    case "$level" in
        3)
            # Sync ramdisk writes back to real filesystem
            local project_name
            project_name="$(basename "$project_root")"
            local mirror_dir="/dev/shm/agent-harness/${project_name}"
            if [[ -d "$mirror_dir" ]]; then
                rsync -a --delete \
                    --exclude='.git/' \
                    --exclude='.git-audit/' \
                    --exclude='node_modules/' \
                    --exclude='.harness-mirror*' \
                    "$mirror_dir/" "$project_root/"
                rc::log INFO "Synced ramdisk writes back to ${project_root}"
            fi
            ;;
    esac
}

# ============================================================================
# STATUS
# ============================================================================

rc::status() {
    local project_root="${1:-$PWD}"

    echo "╔══════════════════════════════════════════════╗"
    echo "║           readcache status                   ║"
    echo "╚══════════════════════════════════════════════╝"
    echo ""

    # Layer 1: Page cache warmer
    echo "  Layer 1 — Page Cache Warmer: ALWAYS AVAILABLE"
    if [[ -d "$RC_CACHE_DIR" ]]; then
        local manifests
        manifests="$(ls "${RC_CACHE_DIR}"/last_warm_*.list 2>/dev/null | wc -l)"
        echo "    Cached manifests: ${manifests}"
        for f in "${RC_CACHE_DIR}"/last_warm_*.list; do
            [[ -f "$f" ]] || continue
            local name
            name="$(basename "$f" .list)"
            name="${name#last_warm_}"
            echo "      ${name}: $(wc -l < "$f") files"
        done
    fi

    echo ""

    # Layer 2: Stat cache shim
    if rc::shim_available; then
        echo "  Layer 2 — Stat Cache Shim: COMPILED"
        echo "    Path: ${RC_SHIM_SO}"
        echo "    TTL: ${HARNESS_STATCACHE_TTL_MS:-100}ms"
    elif [[ -f "$RC_SHIM_SRC" ]]; then
        echo "  Layer 2 — Stat Cache Shim: NOT COMPILED"
        echo "    Source: ${RC_SHIM_SRC}"
        echo "    Run: readcache compile"
    else
        echo "  Layer 2 — Stat Cache Shim: NOT AVAILABLE"
    fi

    echo ""

    # Layer 3: Ramdisk
    local project_name
    project_name="$(basename "$project_root")"
    local mirror_dir="/dev/shm/agent-harness/${project_name}"
    if [[ -d "$mirror_dir" ]]; then
        local mirror_size
        mirror_size="$(du -sh "$mirror_dir" 2>/dev/null | cut -f1)"
        local pidfile="${mirror_dir}/.harness-mirror.pid"
        local watcher_status="STOPPED"
        if [[ -f "$pidfile" ]] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
            watcher_status="RUNNING (pid $(cat "$pidfile"))"
        fi
        echo "  Layer 3 — Ramdisk Mirror: ACTIVE"
        echo "    Path: ${mirror_dir}"
        echo "    Size: ${mirror_size}"
        echo "    Sync: ${watcher_status}"
    else
        echo "  Layer 3 — Ramdisk Mirror: NOT INITIALIZED"
    fi
}
