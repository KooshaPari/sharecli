#!/usr/bin/env bash
# =============================================================================
# agent-harness/lib/core.sh — Core library for agent command harness
#
# Provides process-tree detection, rule parsing, caching, and execution
# strategies (coalesce, queue, debounce, passthrough) for deduplicating
# concurrent commands issued by isolated AI agent processes.
# =============================================================================

set -uo pipefail

# ---------------------------------------------------------------------------
# Paths — all derived from HARNESS_HOME (set by the dispatcher)
# ---------------------------------------------------------------------------
HARNESS_HOME="${HARNESS_HOME:?HARNESS_HOME must be set}"
HARNESS_PROXY="${HARNESS_HOME}/proxy"
HARNESS_LIB="${HARNESS_HOME}/lib"
HARNESS_ETC="${HARNESS_HOME}/etc"
HARNESS_VAR="${HARNESS_HOME}/var"
HARNESS_CACHE="${HARNESS_VAR}/cache"
HARNESS_LOCKS="${HARNESS_VAR}/locks"
HARNESS_LOG="${HARNESS_VAR}/log/harness.log"

# Source optional subsystems
[[ -f "${HARNESS_LIB}/readcache.sh" ]] && source "${HARNESS_LIB}/readcache.sh"

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
harness::log() {
    local level="$1"; shift
    local msg="$*"
    mkdir -p "$(dirname "$HARNESS_LOG")" 2>/dev/null
    printf '[%s] [%s] [pid=%s] %s\n' \
        "$(date '+%Y-%m-%dT%H:%M:%S%z')" "$level" "$$" "$msg" \
        >> "$HARNESS_LOG" 2>/dev/null
}

# ---------------------------------------------------------------------------
# Process-tree agent detection
#
# Walks the parent-process chain looking for known AI agent process names.
# Returns 0 if an agent ancestor is found, 1 otherwise.
# Works on Linux (/proc) with macOS (ps) fallback.
# ---------------------------------------------------------------------------
harness::get_ppid() {
    local pid="$1"
    if [[ -r "/proc/${pid}/stat" ]]; then
        awk '{print $4}' "/proc/${pid}/stat" 2>/dev/null
    else
        ps -o ppid= -p "$pid" 2>/dev/null | tr -d ' '
    fi
}

harness::get_comm() {
    local pid="$1"
    if [[ -r "/proc/${pid}/comm" ]]; then
        cat "/proc/${pid}/comm" 2>/dev/null
    else
        ps -o comm= -p "$pid" 2>/dev/null | xargs 2>/dev/null
    fi
}

harness::get_cmdline() {
    local pid="$1"
    if [[ -r "/proc/${pid}/cmdline" ]]; then
        tr '\0' ' ' < "/proc/${pid}/cmdline" 2>/dev/null
    else
        ps -o args= -p "$pid" 2>/dev/null
    fi
}

harness::is_agent() {
    local agents_file="${HARNESS_ETC}/agents.conf"
    [[ -f "$agents_file" ]] || return 1

    # Load patterns (skip comments and blanks)
    local -a patterns=()
    while IFS= read -r line; do
        line="${line%%#*}"          # strip inline comments
        line="${line// /}"          # strip spaces
        [[ -z "$line" ]] && continue
        patterns+=("$line")
    done < "$agents_file"
    [[ ${#patterns[@]} -eq 0 ]] && return 1

    local pid=$PPID
    local hops=0
    local max_hops=32              # safety limit

    while [[ $pid -gt 1 && $hops -lt $max_hops ]]; do
        local comm cmdline
        comm="$(harness::get_comm "$pid")" || break
        cmdline="$(harness::get_cmdline "$pid")" || cmdline=""

        for pattern in "${patterns[@]}"; do
            if [[ "$comm" == *"$pattern"* ]] || [[ "$cmdline" == *"$pattern"* ]]; then
                harness::log DEBUG "Agent detected: pattern='$pattern' comm='$comm' pid=$pid"
                return 0
            fi
        done

        local new_pid
        new_pid="$(harness::get_ppid "$pid")" || break
        [[ "$new_pid" == "$pid" || -z "$new_pid" ]] && break
        pid="$new_pid"
        ((hops++))
    done
    return 1
}

# ---------------------------------------------------------------------------
# Real binary resolution
#
# Scans PATH to find the actual binary, skipping our proxy directory and
# anything that resolves back to the harness dispatcher.
# ---------------------------------------------------------------------------
harness::find_real() {
    local cmd="$1"

    # First check the pre-cached .real file (written at install time)
    local cached_real="${HARNESS_PROXY}/.${cmd}.real"
    if [[ -f "$cached_real" ]]; then
        local cached_path
        cached_path="$(cat "$cached_real")"
        if [[ -x "$cached_path" ]]; then
            echo "$cached_path"
            return 0
        fi
    fi

    # Fallback: scan PATH, skipping proxy dir
    local harness_real
    harness_real="$(readlink -f "${HARNESS_HOME}/bin/harness" 2>/dev/null || echo "")"
    local proxy_real
    proxy_real="$(readlink -f "${HARNESS_PROXY}" 2>/dev/null || echo "")"

    local IFS=':'
    for dir in $PATH; do
        # Skip our proxy directory
        local dir_real
        dir_real="$(readlink -f "$dir" 2>/dev/null || echo "$dir")"
        [[ "$dir_real" == "$proxy_real" ]] && continue

        local candidate="${dir}/${cmd}"
        if [[ -x "$candidate" ]]; then
            # Ensure it doesn't resolve back to our harness
            local cand_real
            cand_real="$(readlink -f "$candidate" 2>/dev/null || echo "$candidate")"
            [[ -n "$harness_real" && "$cand_real" == "$harness_real" ]] && continue

            echo "$candidate"
            return 0
        fi
    done
    return 1
}

# ---------------------------------------------------------------------------
# Cache key generation
#
# Modes:
#   "args"  — hash(command + args)                     [CWD-independent]
#   "time"  — hash(command + args + CWD)               [default, TTL-based]
#   "git"   — hash(command + args + CWD + git status)  [content-aware]
# ---------------------------------------------------------------------------
harness::cache_key() {
    local mode="$1"; shift
    local cmd="$1"; shift
    # rest of args: "$@"

    local base
    base="$(printf '%s\0' "$cmd" "$@")"

    case "$mode" in
        args)
            printf '%s' "$base" | sha256sum | cut -d' ' -f1
            ;;
        git)
            local git_state=""
            if command -v git &>/dev/null; then
                git_state="$(git -C "$PWD" status --porcelain 2>/dev/null || true)"
                git_state+="$(git -C "$PWD" rev-parse HEAD 2>/dev/null || true)"
            fi
            printf '%s\0%s\0%s' "$base" "$PWD" "$git_state" | sha256sum | cut -d' ' -f1
            ;;
        *)  # "time" or default
            printf '%s\0%s' "$base" "$PWD" | sha256sum | cut -d' ' -f1
            ;;
    esac
}

# ---------------------------------------------------------------------------
# Rule parser
#
# Reads rules.conf and returns the matching rule string for a given
# command:subcommand pair.  Supports exact match and wildcard (*).
#
# Format:  COMMAND[:SUBCOMMAND]  STRATEGY  [key=value ...]
# Returns: "STRATEGY key=value ..." or "passthrough" if no match.
# ---------------------------------------------------------------------------
harness::get_rule() {
    local cmd="$1"
    local subcmd="${2:-}"
    local rules_file="${HARNESS_ETC}/rules.conf"
    [[ -f "$rules_file" ]] || { echo "passthrough"; return; }

    local best_match=""

    while IFS= read -r line; do
        line="${line%%#*}"       # strip comments
        [[ -z "${line// /}" ]] && continue

        local pattern rest
        pattern="$(echo "$line" | awk '{print $1}')"
        rest="$(echo "$line" | cut -d' ' -f2-)"

        local pcmd psub
        if [[ "$pattern" == *:* ]]; then
            pcmd="${pattern%%:*}"
            psub="${pattern#*:}"
        else
            pcmd="$pattern"
            psub="*"
        fi

        if [[ "$pcmd" == "$cmd" ]]; then
            if [[ "$psub" == "$subcmd" ]]; then
                # Exact match — return immediately
                echo "$rest"
                return
            elif [[ "$psub" == "*" ]]; then
                # Wildcard match — keep as fallback
                best_match="$rest"
            fi
        fi
    done < "$rules_file"

    echo "${best_match:-passthrough}"
}

# ---------------------------------------------------------------------------
# Option parser helper
# Extracts key=value from a rule options string.
# ---------------------------------------------------------------------------
harness::opt() {
    local opts="$1"
    local key="$2"
    local default="$3"
    local val
    val="$(echo "$opts" | grep -oP "${key}=\K[^ ]+" 2>/dev/null || true)"
    echo "${val:-$default}"
}

# ---------------------------------------------------------------------------
# Platform-aware file age (seconds since modification)
# ---------------------------------------------------------------------------
harness::file_age() {
    local file="$1"
    local now mtime
    now="$(date +%s)"
    if stat -c %Y "$file" &>/dev/null; then
        mtime="$(stat -c %Y "$file")"       # GNU/Linux
    elif stat -f %m "$file" &>/dev/null; then
        mtime="$(stat -f %m "$file")"       # macOS/BSD
    else
        echo 999999
        return
    fi
    echo $(( now - mtime ))
}

# =============================================================================
# STRATEGIES
# =============================================================================

# ---------------------------------------------------------------------------
# Coalesce (single-flight with caching)
#
# Only one process executes the command at a time.  Concurrent arrivals
# block on an exclusive lock and receive the cached result once the
# executor finishes.  Optional debounce adds a short delay to batch
# near-simultaneous invocations.
#
# Args: real_cmd cache_key ttl debounce_ms error_ttl [cmd_args...]
# ---------------------------------------------------------------------------
harness::strategy::coalesce() {
    local real_cmd="$1"; shift
    local cache_key="$1"; shift
    local ttl="$1"; shift
    local debounce_ms="$1"; shift
    local error_ttl="$1"; shift
    # remaining: "$@" = arguments to pass to real command

    local lock="${HARNESS_LOCKS}/${cache_key}.lock"
    local out="${HARNESS_CACHE}/${cache_key}.out"
    local err="${HARNESS_CACHE}/${cache_key}.err"
    local rc="${HARNESS_CACHE}/${cache_key}.rc"

    mkdir -p "$HARNESS_CACHE" "$HARNESS_LOCKS" 2>/dev/null

    # Acquire exclusive lock (blocks if held by another process)
    exec 200>"$lock"
    flock -x 200

    # --- Check cache freshness ---
    if [[ -f "$rc" && -f "$out" ]]; then
        local age effective_ttl cached_code
        age="$(harness::file_age "$rc")"
        cached_code="$(cat "$rc" 2>/dev/null || echo 255)"

        # Use shorter TTL for errors if configured
        if [[ "$cached_code" -ne 0 && "$error_ttl" -gt 0 ]]; then
            effective_ttl="$error_ttl"
        else
            effective_ttl="$ttl"
        fi

        if [[ "$age" -lt "$effective_ttl" ]]; then
            harness::log INFO "CACHE HIT key=${cache_key:0:12}… age=${age}s ttl=${effective_ttl}s"
            cat "$out" 2>/dev/null
            cat "$err" >&2 2>/dev/null
            flock -u 200
            return "$cached_code"
        fi
    fi

    # --- Cache miss: optional debounce ---
    if [[ "$debounce_ms" -gt 0 ]]; then
        local sleep_s
        sleep_s="$(awk "BEGIN{printf \"%.3f\", ${debounce_ms}/1000}")"
        harness::log DEBUG "Debouncing ${sleep_s}s before execution"
        sleep "$sleep_s" 2>/dev/null || sleep 1
    fi

    # --- Pre-exec: warm file read cache if available ---
    if declare -f rc::pre_exec &>/dev/null; then
        local _rc_level="${HARNESS_READCACHE_LEVEL:-1}"
        local _rc_cmd _rc_subcmd
        _rc_cmd="$(basename "$real_cmd")"
        _rc_subcmd="${1:-}"
        rc::pre_exec "${PWD}" "$_rc_cmd" "$_rc_subcmd" "$_rc_level" 2>/dev/null
    fi

    # --- Execute the real command (atomic write to cache) ---
    harness::log INFO "EXEC key=${cache_key:0:12}… cmd=$(basename "$real_cmd") $*"

    "$real_cmd" "$@" >"${out}.tmp" 2>"${err}.tmp"
    local code=$?
    echo "$code" > "${rc}.tmp"

    # Atomic rename
    mv -f "${out}.tmp" "$out"
    mv -f "${err}.tmp" "$err"
    mv -f "${rc}.tmp" "$rc"

    # Output
    cat "$out"
    cat "$err" >&2

    flock -u 200
    return "$code"
}

# ---------------------------------------------------------------------------
# Queue (concurrency limiter)
#
# Allows up to N concurrent executions of the same command.  Additional
# callers block until a slot opens.  No caching — every caller runs the
# real command, just with bounded parallelism.
#
# Args: real_cmd cmd_name max_concurrent [cmd_args...]
# ---------------------------------------------------------------------------
harness::strategy::queue() {
    local real_cmd="$1"; shift
    local cmd_name="$1"; shift
    local max_concurrent="$1"; shift

    mkdir -p "$HARNESS_LOCKS" 2>/dev/null

    local slot
    for (( slot = 0; slot < max_concurrent; slot++ )); do
        local lock_file="${HARNESS_LOCKS}/${cmd_name}.slot${slot}.lock"

        # Try to grab this slot non-blocking
        eval "exec $((210 + slot))>\"$lock_file\""
        if flock -n "$((210 + slot))" 2>/dev/null; then
            harness::log INFO "QUEUE slot=${slot}/${max_concurrent} cmd=$cmd_name"
            "$real_cmd" "$@"
            local code=$?
            flock -u "$((210 + slot))"
            return "$code"
        fi
    done

    # All slots occupied — block on slot 0
    harness::log INFO "QUEUE FULL — waiting on slot=0 cmd=$cmd_name"
    local lock_file="${HARNESS_LOCKS}/${cmd_name}.slot0.lock"
    exec 210>"$lock_file"
    flock -x 210
    "$real_cmd" "$@"
    local code=$?
    flock -u 210
    return "$code"
}

# ---------------------------------------------------------------------------
# Debounce (delay without caching)
#
# Adds a short delay before execution.  Useful for mutating commands
# where caching is unsafe but you still want to absorb rapid-fire calls.
#
# Args: real_cmd debounce_ms [cmd_args...]
# ---------------------------------------------------------------------------
harness::strategy::debounce() {
    local real_cmd="$1"; shift
    local debounce_ms="$1"; shift

    if [[ "$debounce_ms" -gt 0 ]]; then
        local sleep_s
        sleep_s="$(awk "BEGIN{printf \"%.3f\", ${debounce_ms}/1000}")"
        sleep "$sleep_s" 2>/dev/null || sleep 1
    fi

    exec "$real_cmd" "$@"
}

# ---------------------------------------------------------------------------
# Cache stats (for `harness status`)
# ---------------------------------------------------------------------------
harness::cache_stats() {
    local total hits_possible
    total="$(find "$HARNESS_CACHE" -name '*.rc' 2>/dev/null | wc -l)"
    local fresh=0
    while IFS= read -r rcfile; do
        local age
        age="$(harness::file_age "$rcfile")"
        [[ "$age" -lt 30 ]] && ((fresh++))
    done < <(find "$HARNESS_CACHE" -name '*.rc' 2>/dev/null)
    echo "total=$total fresh=$fresh"
}
