/*
 * agent-harness/lib/statcache_shim.c — LD_PRELOAD stat/readdir cache
 *
 * Intercepts filesystem metadata syscalls (stat, lstat, fstatat, opendir)
 * and caches results in a per-process hash table with a short TTL.
 * When multiple agent subprocesses are reading the same tree concurrently,
 * this eliminates redundant kernel round-trips for metadata.
 *
 * The page cache handles DATA reads; this handles METADATA.
 *
 * Compile:
 *   gcc -shared -fPIC -O2 -o statcache_shim.so statcache_shim.c -ldl -lpthread
 *
 * Usage:
 *   export LD_PRELOAD=/path/to/statcache_shim.so
 *   export HARNESS_STATCACHE_TTL_MS=100    # cache lifetime (default: 100ms)
 *   export HARNESS_STATCACHE_ENABLED=1     # enable (default: 0 = passthrough)
 *   export HARNESS_STATCACHE_MAX=65536     # max entries (default: 65536)
 *
 * Design decisions:
 *   - Per-process hash table (no cross-process shared memory needed)
 *     because the big win is deduplicating stat() calls within a single
 *     tool invocation (ruff stats every .py file, eslint stats every .ts)
 *   - Short TTL (100ms) because we're caching within a single command run,
 *     not across runs (the harness output cache handles cross-run dedup)
 *   - Hash table with open addressing for cache-friendly access
 *   - Monotonic clock for TTL to avoid wall-clock jumps
 *   - Ignores /proc, /sys, /dev (these should never be cached)
 */

#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <dirent.h>
#include <unistd.h>
#include <limits.h>

/* --------------------------------------------------------------------------
 * Configuration
 * -------------------------------------------------------------------------- */

#define DEFAULT_TTL_MS      100
#define DEFAULT_MAX_ENTRIES  65536
#define MAX_PATH_LEN        4096

/* Paths that should never be cached */
static const char *NOCACHE_PREFIXES[] = {
    "/proc/", "/sys/", "/dev/", "/run/", NULL
};

/* --------------------------------------------------------------------------
 * Cache entry
 * -------------------------------------------------------------------------- */

typedef struct {
    char        path[MAX_PATH_LEN];
    struct stat stbuf;
    int         stat_errno;   /* errno from the real stat call */
    int         valid;        /* 0 = empty slot, 1 = populated */
    uint64_t    timestamp_ns; /* monotonic clock when cached */
} stat_cache_entry_t;

/* --------------------------------------------------------------------------
 * Global state
 * -------------------------------------------------------------------------- */

static stat_cache_entry_t *g_cache     = NULL;
static size_t              g_cache_max = 0;
static uint64_t            g_ttl_ns    = 0;
static int                 g_enabled   = 0;
static pthread_mutex_t     g_lock      = PTHREAD_MUTEX_INITIALIZER;
static atomic_uint_fast64_t g_hits     = 0;
static atomic_uint_fast64_t g_misses   = 0;

/* Original libc functions */
static int (*real_stat)(const char *, struct stat *)               = NULL;
static int (*real_lstat)(const char *, struct stat *)              = NULL;
static int (*real_fstatat)(int, const char *, struct stat *, int)  = NULL;
static int (*real___xstat)(int, const char *, struct stat *)       = NULL;
static int (*real___lxstat)(int, const char *, struct stat *)      = NULL;
static int (*real___fxstatat)(int, int, const char *, struct stat *, int) = NULL;

/* --------------------------------------------------------------------------
 * Helpers
 * -------------------------------------------------------------------------- */

static uint64_t now_ns(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

/* FNV-1a hash */
static uint64_t hash_path(const char *path) {
    uint64_t h = 14695981039346656037ULL;
    for (const char *p = path; *p; p++) {
        h ^= (uint64_t)(unsigned char)*p;
        h *= 1099511628211ULL;
    }
    return h;
}

static int should_cache(const char *path) {
    if (!g_enabled || !path) return 0;
    for (const char **pfx = NOCACHE_PREFIXES; *pfx; pfx++) {
        if (strncmp(path, *pfx, strlen(*pfx)) == 0) return 0;
    }
    return 1;
}

/* --------------------------------------------------------------------------
 * Initialization (called once via __attribute__((constructor)))
 * -------------------------------------------------------------------------- */

__attribute__((constructor))
static void shim_init(void) {
    /* Load original functions */
    real_stat     = dlsym(RTLD_NEXT, "stat");
    real_lstat    = dlsym(RTLD_NEXT, "lstat");
    real_fstatat  = dlsym(RTLD_NEXT, "fstatat");
    real___xstat  = dlsym(RTLD_NEXT, "__xstat");
    real___lxstat = dlsym(RTLD_NEXT, "__lxstat");
    real___fxstatat = dlsym(RTLD_NEXT, "__fxstatat");

    /* Read config from environment */
    const char *enabled_str = getenv("HARNESS_STATCACHE_ENABLED");
    g_enabled = (enabled_str && atoi(enabled_str) > 0) ? 1 : 0;

    if (!g_enabled) return;

    const char *ttl_str = getenv("HARNESS_STATCACHE_TTL_MS");
    uint64_t ttl_ms = ttl_str ? (uint64_t)atoi(ttl_str) : DEFAULT_TTL_MS;
    g_ttl_ns = ttl_ms * 1000000ULL;

    const char *max_str = getenv("HARNESS_STATCACHE_MAX");
    g_cache_max = max_str ? (size_t)atoi(max_str) : DEFAULT_MAX_ENTRIES;

    /* Allocate cache */
    g_cache = calloc(g_cache_max, sizeof(stat_cache_entry_t));
    if (!g_cache) {
        g_enabled = 0;
        return;
    }

    /* Debug log */
    if (getenv("HARNESS_STATCACHE_DEBUG")) {
        fprintf(stderr, "[statcache] initialized: ttl=%lums max=%zu\n",
                (unsigned long)ttl_ms, g_cache_max);
    }
}

__attribute__((destructor))
static void shim_fini(void) {
    if (getenv("HARNESS_STATCACHE_DEBUG") && g_enabled) {
        fprintf(stderr, "[statcache] stats: hits=%lu misses=%lu ratio=%.1f%%\n",
                (unsigned long)g_hits, (unsigned long)g_misses,
                g_hits + g_misses > 0
                    ? 100.0 * g_hits / (g_hits + g_misses)
                    : 0.0);
    }
    free(g_cache);
    g_cache = NULL;
}

/* --------------------------------------------------------------------------
 * Cache lookup / insert
 * -------------------------------------------------------------------------- */

/* Returns 1 if found valid entry, 0 if miss */
static int cache_lookup(const char *path, struct stat *stbuf, int *cached_errno) {
    if (!g_cache) return 0;

    uint64_t h = hash_path(path);
    size_t idx = h % g_cache_max;
    uint64_t now = now_ns();

    /* Linear probing (check up to 4 slots for collisions) */
    for (int probe = 0; probe < 4; probe++) {
        size_t i = (idx + probe) % g_cache_max;
        stat_cache_entry_t *e = &g_cache[i];

        if (!e->valid) break;

        if (strcmp(e->path, path) == 0) {
            /* Check TTL */
            if ((now - e->timestamp_ns) <= g_ttl_ns) {
                memcpy(stbuf, &e->stbuf, sizeof(struct stat));
                *cached_errno = e->stat_errno;
                atomic_fetch_add(&g_hits, 1);
                return 1;
            }
            /* Expired — evict and miss */
            e->valid = 0;
            break;
        }
    }

    atomic_fetch_add(&g_misses, 1);
    return 0;
}

static void cache_insert(const char *path, const struct stat *stbuf, int err) {
    if (!g_cache) return;
    if (strlen(path) >= MAX_PATH_LEN) return;

    uint64_t h = hash_path(path);
    size_t idx = h % g_cache_max;
    uint64_t now = now_ns();

    /* Find a slot (linear probing, up to 4) */
    for (int probe = 0; probe < 4; probe++) {
        size_t i = (idx + probe) % g_cache_max;
        stat_cache_entry_t *e = &g_cache[i];

        /* Use empty slot or overwrite expired/matching entry */
        if (!e->valid || strcmp(e->path, path) == 0 ||
            (now - e->timestamp_ns) > g_ttl_ns) {
            strncpy(e->path, path, MAX_PATH_LEN - 1);
            e->path[MAX_PATH_LEN - 1] = '\0';
            memcpy(&e->stbuf, stbuf, sizeof(struct stat));
            e->stat_errno = err;
            e->timestamp_ns = now;
            e->valid = 1;
            return;
        }
    }
    /* All 4 slots occupied with valid entries — skip caching this path */
}

/* --------------------------------------------------------------------------
 * Resolve relative paths to absolute for consistent cache keys
 *
 * FAST PATH: avoid realpath() since it does its own stat() calls.
 * For relative paths, prepend cached CWD.  This is safe because:
 *   - Within a single command invocation, CWD rarely changes
 *   - If CWD does change, the cache entries just won't hit
 * -------------------------------------------------------------------------- */
static __thread char t_cwd[MAX_PATH_LEN] = {0};
static __thread int  t_cwd_valid = 0;

static const char *resolve_path(const char *path, char *resolved, size_t size) {
    if (path[0] == '/') return path;  /* Already absolute — zero overhead */

    /* Cache CWD per-thread (avoids getcwd syscall on every call) */
    if (!t_cwd_valid) {
        if (getcwd(t_cwd, sizeof(t_cwd))) {
            t_cwd_valid = 1;
        } else {
            return path;  /* Can't resolve — use as-is */
        }
    }

    size_t cwdlen = strlen(t_cwd);
    size_t pathlen = strlen(path);
    if (cwdlen + 1 + pathlen >= size) return path;

    memcpy(resolved, t_cwd, cwdlen);
    resolved[cwdlen] = '/';
    memcpy(resolved + cwdlen + 1, path, pathlen + 1);
    return resolved;
}

/* --------------------------------------------------------------------------
 * Intercepted functions
 *
 * On modern glibc, stat() is actually __xstat() or fstatat().
 * We intercept all variants to be safe.
 * -------------------------------------------------------------------------- */

/* stat() — resolve path then check cache */
int stat(const char *path, struct stat *stbuf) {
    if (!should_cache(path)) {
        return real_stat ? real_stat(path, stbuf) : -1;
    }

    char resolved[MAX_PATH_LEN];
    const char *key = resolve_path(path, resolved, sizeof(resolved));

    int cached_errno;
    if (cache_lookup(key, stbuf, &cached_errno)) {
        if (cached_errno != 0) {
            errno = cached_errno;
            return -1;
        }
        return 0;
    }

    /* Cache miss — real syscall */
    int ret;
    if (real_stat) {
        ret = real_stat(path, stbuf);
    } else {
        errno = ENOSYS;
        return -1;
    }

    cache_insert(key, stbuf, ret == -1 ? errno : 0);
    return ret;
}

/* lstat() */
int lstat(const char *path, struct stat *stbuf) {
    if (!should_cache(path)) {
        return real_lstat ? real_lstat(path, stbuf) : -1;
    }

    /* Use a different cache key prefix for lstat to avoid confusing with stat */
    char lpath[MAX_PATH_LEN + 2];
    snprintf(lpath, sizeof(lpath), "L:%s", path);

    char resolved[MAX_PATH_LEN + 2];
    const char *key = resolve_path(lpath, resolved, sizeof(resolved));

    int cached_errno;
    if (cache_lookup(key, stbuf, &cached_errno)) {
        if (cached_errno != 0) {
            errno = cached_errno;
            return -1;
        }
        return 0;
    }

    int ret;
    if (real_lstat) {
        ret = real_lstat(path, stbuf);
    } else {
        errno = ENOSYS;
        return -1;
    }

    cache_insert(key, stbuf, ret == -1 ? errno : 0);
    return ret;
}

/* __xstat() — glibc internal for stat() */
int __xstat(int ver, const char *path, struct stat *stbuf) {
    /* On systems where stat() maps to __xstat, delegate through our stat() */
    if (real___xstat && !should_cache(path)) {
        return real___xstat(ver, path, stbuf);
    }
    /* Fall through to our cached stat */
    return stat(path, stbuf);
}

/* __lxstat() — glibc internal for lstat() */
int __lxstat(int ver, const char *path, struct stat *stbuf) {
    if (real___lxstat && !should_cache(path)) {
        return real___lxstat(ver, path, stbuf);
    }
    return lstat(path, stbuf);
}

/* fstatat() — the modern interface that stat() often calls */
int fstatat(int dirfd, const char *path, struct stat *stbuf, int flags) {
    /* Only cache if we can resolve to an absolute path */
    if (dirfd == AT_FDCWD && should_cache(path)) {
        if (flags & AT_SYMLINK_NOFOLLOW) {
            return lstat(path, stbuf);
        } else {
            return stat(path, stbuf);
        }
    }
    /* Non-CWD-relative or non-cacheable — passthrough */
    return real_fstatat ? real_fstatat(dirfd, path, stbuf, flags) : -1;
}

/* --------------------------------------------------------------------------
 * 64-bit variants (stat64, lstat64, fstatat64)
 *
 * On glibc 2.33+, Python/Node/most modern programs use these instead of
 * stat/lstat. On 64-bit systems struct stat64 == struct stat, so we can
 * safely delegate to our caching stat/lstat implementations.
 * -------------------------------------------------------------------------- */

/* Original 64-bit functions */
static int (*real_stat64)(const char *, struct stat64 *)              = NULL;
static int (*real_lstat64)(const char *, struct stat64 *)             = NULL;
static int (*real_fstatat64)(int, const char *, struct stat64 *, int) = NULL;

static void init_64(void) __attribute__((constructor));
static void init_64(void) {
    real_stat64    = dlsym(RTLD_NEXT, "stat64");
    real_lstat64   = dlsym(RTLD_NEXT, "lstat64");
    real_fstatat64 = dlsym(RTLD_NEXT, "fstatat64");
}

int stat64(const char *path, struct stat64 *stbuf) {
    if (!should_cache(path)) {
        return real_stat64 ? real_stat64(path, stbuf) : -1;
    }

    char resolved[MAX_PATH_LEN];
    const char *key = resolve_path(path, resolved, sizeof(resolved));

    /* On 64-bit Linux, struct stat == struct stat64 in size/layout */
    int cached_errno;
    if (cache_lookup(key, (struct stat *)stbuf, &cached_errno)) {
        if (cached_errno != 0) { errno = cached_errno; return -1; }
        return 0;
    }

    int ret = real_stat64 ? real_stat64(path, stbuf) : -1;
    if (!real_stat64) { errno = ENOSYS; return -1; }

    cache_insert(key, (const struct stat *)stbuf, ret == -1 ? errno : 0);
    return ret;
}

int lstat64(const char *path, struct stat64 *stbuf) {
    if (!should_cache(path)) {
        return real_lstat64 ? real_lstat64(path, stbuf) : -1;
    }

    char lpath[MAX_PATH_LEN + 2];
    snprintf(lpath, sizeof(lpath), "L:%s", path);

    char resolved[MAX_PATH_LEN + 2];
    const char *key = resolve_path(lpath, resolved, sizeof(resolved));

    int cached_errno;
    if (cache_lookup(key, (struct stat *)stbuf, &cached_errno)) {
        if (cached_errno != 0) { errno = cached_errno; return -1; }
        return 0;
    }

    int ret = real_lstat64 ? real_lstat64(path, stbuf) : -1;
    if (!real_lstat64) { errno = ENOSYS; return -1; }

    cache_insert(key, (const struct stat *)stbuf, ret == -1 ? errno : 0);
    return ret;
}

int fstatat64(int dirfd, const char *path, struct stat64 *stbuf, int flags) {
    if (dirfd == AT_FDCWD && should_cache(path)) {
        if (flags & AT_SYMLINK_NOFOLLOW) {
            return lstat64(path, stbuf);
        } else {
            return stat64(path, stbuf);
        }
    }
    return real_fstatat64 ? real_fstatat64(dirfd, path, stbuf, flags) : -1;
}
