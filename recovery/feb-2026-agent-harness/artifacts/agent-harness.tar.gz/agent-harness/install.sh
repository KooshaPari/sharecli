#!/usr/bin/env bash
# =============================================================================
# agent-harness/install.sh — Installer
#
# Usage:
#   ./install.sh              # Default: user-level install (~/.local/share/)
#   ./install.sh --user       # Explicit user-level
#   ./install.sh --system     # System-wide (/opt/agent-harness, needs sudo)
#   ./install.sh --dir /path  # Custom directory
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
MODE="user"
CUSTOM_DIR=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --user)    MODE="user";   shift ;;
        --system)  MODE="system"; shift ;;
        --dir)     MODE="custom"; CUSTOM_DIR="$2"; shift 2 ;;
        --help|-h)
            echo "Usage: $0 [--user | --system | --dir /path]"
            exit 0
            ;;
        *) echo "Unknown option: $1" >&2; exit 1 ;;
    esac
done

# ---------------------------------------------------------------------------
# Determine install directory
# ---------------------------------------------------------------------------
case "$MODE" in
    user)
        INSTALL_DIR="${HOME}/.local/share/agent-harness"
        PROFILE_FILE="${HOME}/.bashrc"
        ;;
    system)
        INSTALL_DIR="/opt/agent-harness"
        PROFILE_FILE="/etc/profile.d/agent-harness.sh"
        ;;
    custom)
        INSTALL_DIR="$CUSTOM_DIR"
        PROFILE_FILE="${HOME}/.bashrc"
        ;;
esac

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "╔══════════════════════════════════════════════════╗"
echo "║         agent-harness installer                  ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "  Mode:        ${MODE}"
echo "  Install to:  ${INSTALL_DIR}"
echo "  Source from:  ${SOURCE_DIR}"
echo ""

# ---------------------------------------------------------------------------
# Create directory structure
# ---------------------------------------------------------------------------
if [[ "$MODE" == "system" ]]; then
    sudo mkdir -p "$INSTALL_DIR"/{bin,lib,etc,proxy,var/{cache,locks,log}}
    SUDO="sudo"
else
    mkdir -p "$INSTALL_DIR"/{bin,lib,etc,proxy,var/{cache,locks,log}}
    SUDO=""
fi

# ---------------------------------------------------------------------------
# Copy files
# ---------------------------------------------------------------------------
echo "── Copying files ──"

$SUDO cp "${SOURCE_DIR}/bin/harness"   "${INSTALL_DIR}/bin/harness"
$SUDO cp "${SOURCE_DIR}/bin/audit"     "${INSTALL_DIR}/bin/audit"
$SUDO cp "${SOURCE_DIR}/lib/core.sh"   "${INSTALL_DIR}/lib/core.sh"
$SUDO cp "${SOURCE_DIR}/lib/audit-hooks.sh" "${INSTALL_DIR}/lib/audit-hooks.sh"
$SUDO cp "${SOURCE_DIR}/lib/readcache.sh" "${INSTALL_DIR}/lib/readcache.sh"
$SUDO cp "${SOURCE_DIR}/lib/statcache_shim.c" "${INSTALL_DIR}/lib/statcache_shim.c"
# Compile stat cache shim if gcc available
if command -v gcc &>/dev/null; then
    echo "Compiling stat cache shim..."
    gcc -shared -fPIC -O2 \
        -o "${INSTALL_DIR}/lib/statcache_shim.so" \
        "${INSTALL_DIR}/lib/statcache_shim.c" \
        -ldl -lpthread 2>/dev/null && echo "  ✓ Stat cache shim compiled" || echo "  ⚠ Stat cache shim compilation failed (optional)"
fi
$SUDO chmod +x "${INSTALL_DIR}/bin/harness" "${INSTALL_DIR}/bin/audit"
# Create agit alias (symlink to audit, dispatches to audit git)
$SUDO ln -sf audit "${INSTALL_DIR}/bin/agit"

# Only copy config files if they don't already exist (preserve user edits)
if [[ ! -f "${INSTALL_DIR}/etc/rules.conf" ]]; then
    $SUDO cp "${SOURCE_DIR}/etc/rules.conf" "${INSTALL_DIR}/etc/rules.conf"
    echo "  Created etc/rules.conf"
else
    echo "  Kept existing etc/rules.conf"
fi

if [[ ! -f "${INSTALL_DIR}/etc/agents.conf" ]]; then
    $SUDO cp "${SOURCE_DIR}/etc/agents.conf" "${INSTALL_DIR}/etc/agents.conf"
    echo "  Created etc/agents.conf"
else
    echo "  Kept existing etc/agents.conf"
fi

# ---------------------------------------------------------------------------
# Sync proxy symlinks
# ---------------------------------------------------------------------------
echo ""
echo "── Syncing proxy symlinks ──"
export HARNESS_HOME="$INSTALL_DIR"
export PATH="${INSTALL_DIR}/proxy:${PATH}"

# Run sync logic inline (since we can't easily call 'harness sync' yet)
rules_file="${INSTALL_DIR}/etc/rules.conf"
proxy_dir="${INSTALL_DIR}/proxy"

# Clean old symlinks
for f in "${proxy_dir}/"*; do
    fname="$(basename "$f" 2>/dev/null || true)"
    [[ "$fname" == .* ]] && continue
    [[ -L "$f" ]] && $SUDO rm "$f"
done
$SUDO rm -f "${proxy_dir}"/.*.real 2>/dev/null || true

# Create new ones
declare -A seen=()
while IFS= read -r line; do
    line="${line%%#*}"
    [[ -z "${line// /}" ]] && continue
    pattern="$(echo "$line" | awk '{print $1}')"
    cmd="${pattern%%:*}"

    [[ -n "${seen[$cmd]+x}" ]] && continue
    seen[$cmd]=1

    # Find real binary (excluding our proxy dir)
    real_path=""
    IFS=':' read -ra path_dirs <<< "$PATH"
    for dir in "${path_dirs[@]}"; do
        dir_real="$(readlink -f "$dir" 2>/dev/null || echo "$dir")"
        proxy_real="$(readlink -f "$proxy_dir" 2>/dev/null || echo "$proxy_dir")"
        [[ "$dir_real" == "$proxy_real" ]] && continue

        if [[ -x "${dir}/${cmd}" ]]; then
            real_path="${dir}/${cmd}"
            break
        fi
    done

    if [[ -z "$real_path" ]]; then
        echo "  SKIP  ${cmd} (not found in PATH)"
        continue
    fi

    $SUDO ln -sf "../bin/harness" "${proxy_dir}/${cmd}"
    echo "$real_path" | $SUDO tee "${proxy_dir}/.${cmd}.real" > /dev/null
    echo "  OK    ${cmd} → ${real_path}"
done < "$rules_file"

# ---------------------------------------------------------------------------
# Set up PATH
# ---------------------------------------------------------------------------
echo ""
echo "── Configuring PATH ──"

PATH_LINE="export PATH=\"${INSTALL_DIR}/proxy:${INSTALL_DIR}/bin:\$PATH\"  # agent-harness"
MARKER="# agent-harness"

if [[ "$MODE" == "system" ]]; then
    # System-wide profile.d script
    echo "$PATH_LINE" | sudo tee "$PROFILE_FILE" > /dev/null
    echo "  Written to ${PROFILE_FILE}"
else
    # User-level .bashrc
    if grep -qF "$MARKER" "$PROFILE_FILE" 2>/dev/null; then
        # Update existing line
        sed -i "/${MARKER}/c\\${PATH_LINE}" "$PROFILE_FILE"
        echo "  Updated existing entry in ${PROFILE_FILE}"
    else
        echo "" >> "$PROFILE_FILE"
        echo "$PATH_LINE" >> "$PROFILE_FILE"
        echo "  Appended to ${PROFILE_FILE}"
    fi
fi

# ---------------------------------------------------------------------------
# Ensure var directories are writable
# ---------------------------------------------------------------------------
if [[ "$MODE" == "system" ]]; then
    sudo chmod -R 1777 "${INSTALL_DIR}/var"
fi

# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  ✓ Installation complete                        ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "  To activate in the current shell:"
echo "    export PATH=\"${INSTALL_DIR}/proxy:\$PATH\""
echo ""
echo "  To verify:"
echo "    ${INSTALL_DIR}/bin/harness status"
echo "    ${INSTALL_DIR}/bin/harness test"
echo ""
echo "  To customize:"
echo "    \$EDITOR ${INSTALL_DIR}/etc/rules.conf"
echo "    \$EDITOR ${INSTALL_DIR}/etc/agents.conf"
echo "    ${INSTALL_DIR}/bin/harness sync  # after editing rules"
echo ""
