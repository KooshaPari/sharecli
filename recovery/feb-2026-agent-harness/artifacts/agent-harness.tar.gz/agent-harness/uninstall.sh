#!/usr/bin/env bash
# =============================================================================
# agent-harness/uninstall.sh — Clean removal
# =============================================================================

set -euo pipefail

echo "agent-harness uninstaller"
echo ""

# Check for common install locations
CANDIDATES=(
    "${HOME}/.local/share/agent-harness"
    "/opt/agent-harness"
)

FOUND=""
for dir in "${CANDIDATES[@]}"; do
    if [[ -d "$dir" && -f "${dir}/bin/harness" ]]; then
        FOUND="$dir"
        break
    fi
done

if [[ -z "$FOUND" ]]; then
    echo "No agent-harness installation found."
    echo "Checked: ${CANDIDATES[*]}"
    exit 0
fi

echo "Found installation at: ${FOUND}"
read -p "Remove it? [y/N] " confirm
[[ "$confirm" != [yY]* ]] && { echo "Aborted."; exit 0; }

# Remove PATH entry from .bashrc
MARKER="# agent-harness"
if grep -qF "$MARKER" "${HOME}/.bashrc" 2>/dev/null; then
    sed -i "/${MARKER}/d" "${HOME}/.bashrc"
    echo "  Removed PATH entry from ~/.bashrc"
fi

# Remove system profile.d entry
if [[ -f "/etc/profile.d/agent-harness.sh" ]]; then
    sudo rm "/etc/profile.d/agent-harness.sh"
    echo "  Removed /etc/profile.d/agent-harness.sh"
fi

# Remove installation directory
if [[ "$FOUND" == /opt/* ]]; then
    sudo rm -rf "$FOUND"
else
    rm -rf "$FOUND"
fi
echo "  Removed ${FOUND}"

echo ""
echo "✓ agent-harness has been uninstalled."
echo "  Restart your shell or run: hash -r"
